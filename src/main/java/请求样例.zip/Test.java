import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import javax.crypto.Cipher;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.security.*;
import java.security.spec.*;
import java.util.HashMap;
import java.util.Map;

public class Test {

    private static final String ALG_RSA = "RSA";
    private static final String ALG_DSA = "DSA";

    public static void main(String[] args) {
        new Test().sendTest();
    }

    public void sendTest() {
        Map<String, Object> param = new HashMap<>();
        param.put("partnerNo", "JDZAD");
        param.put("imeiNo", "15821811805");
        param.put("channelCode", "za");

        Map<String, Object> context = new HashMap<>();
        context.put("id", "adChannelAPI.addDevice");
        context.put("param", param);

        String publicKey = "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBANfa49Gf6bwGhXFCWr+QmIjpcLVJ9VF8oNhOUM74nJKy+BD/W7O3Yl1MvUOODJ6Om7FoEgvMc6qLSerCfarh4K0CAwEAAQ==";
        String bizParam = this.encrypt(JSONObject.toJSONString(context), publicKey);


        Map<String, Object> request = new HashMap<>();
        request.put("apiKey", "ad.device.add");
        request.put("bizParam", bizParam);

        String jsonObject = postByJson("https://finance-gateway-test.diandian.com.cn/fcpGateway", request);
        System.out.println(jsonObject);

    }

    public String encrypt(String context, String publicKey) {
        String encryptedContext = context;
        try {
            if (StringUtils.isEmpty(context)) {
                return encryptedContext;
            }

            encryptedContext = RSAEncrypt.encrypt(context, publicKey);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return encryptedContext;
    }


    protected String  postByJson(String serverUrl, Object param) {
        String jsonStr = null;
        if (param != null) {
            jsonStr = JSON.toJSONString(param);
        }
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        HttpPost httpPost = new HttpPost(serverUrl);
        httpPost.setHeader("Content-Type", "application/json;charset=utf8");
        StringEntity entity = new StringEntity(jsonStr, "UTF-8");
        httpPost.setEntity(entity);
        String resp=null;
        CloseableHttpResponse response = null;
        try{
            response = httpClient.execute(httpPost);
            resp= EntityUtils.toString(response.getEntity());
        }catch (Exception e){
            e.printStackTrace();
        }
        return resp;
    }
}